#include<stdio.h>

/* The side size of the square*/
#define N 3

/*
 This function will get as an input a mat and return if the mat is a magic square
*/
int is_magic(int mat[N][N]);